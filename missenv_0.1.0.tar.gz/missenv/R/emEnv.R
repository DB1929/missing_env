#' EM Envelope Estimation
#'
#' Calculate the estimated envelope estimator under the presence of missing data using the EM algorithm.
#' @name emEnv
#' @param X Predictors matrix of dimension n by p.
#' @param Y Responses matrix of dimension n by r.
#' @param d Tolerance level to stop the algorithm. If the difference in l_1 norm in beta bewteen two updates is less than d, then the algorithm stops.
#' @param maxIter Max iteration of the algorithm.
#' @return A list of estimated envelope dimension, beta, Sigma and Gamma.
#' @details This function calculates the envelope estimators using the EM algorithm proposed in Ma et al.
#' @examples
#' emEnv(predictor, response)
#' @references Ma, L., Liu, L. and Yang, W. Envelope Method with Ignorable Missing Data. Submitted
#' @export


#----------------------------Packages-----------------------------------------
require(Matrix)
require(MASS)
#---------------------------------Functions-----------------------------------
#------EM envelope function------
emEnv <- function(X, Y, d = 0.01, maxIter = 100){
  bic_0 = Inf
  Gamma_t <- matrix(rep(0, ncol(Y)), ncol = 1)
  for (u in 1:dim(Y)[2]){
    mu_t <- rep(0, dim(X)[2])
    Sigma_x_t <- diag(dim(X)[2])
    beta_t <- matrix(rep(0, dim(Y)[2]*dim(X)[2]), nrow = dim(X)[2])
    Sigma_y_t <- diag(dim(Y)[2])
    #------------------------------env_em------------------------------------
    update_list <- update_par(X, Y, mu_t, Sigma_x_t, Sigma_y_t, beta_t, u, Gamma_t)
    k = 0
    while (l1_norm(beta_t - update_list[[4]]) > d & k < maxIter) {
      k = k+1
      mu_t <- update_list[[1]]
      Sigma_x_t <- update_list[[2]]
      Sigma_y_t <- update_list[[3]]
      beta_t <- update_list[[4]]
      Gamma_t <- update_list[[5]]
      if (u == 1)
        update_list <- update_par(X, Y, mu_t, Sigma_x_t, Sigma_y_t, beta_t, u, Gamma_t)
      else
        update_list <- update_par(X, Y, mu_t, Sigma_x_t, Sigma_y_t, beta_t, u, Gamma_t[,1:(u-1)])
      print(l1_norm(beta_t - update_list[[4]]))
    }
    bic <- update_list[[6]]
    if(bic < bic_0){
      bic_0 <- bic
      beta_t_min <- beta_t
      Gamma_t_min <- Gamma_t
      Sigma_y_t_min <- Sigma_y_t
      u0 <- u
    }
    print(u)
  }
  print("We choose envelope dimension")
  print(u0)
  return(list(u0, beta_t_min, Sigma_y_t_min, Gamma_t_min))
}



#Projection matrix
P <- function(A){
  q <- qr(A)
  Q <- qr.Q(q)[, 1:q$rank]
  Q %*% t(Q)
}
Q <- function(A){
  a <- nrow(A)
  diag(a) - P(A)
}

#Input a vector, output a permutation matrix related to the location of NAs
Pmt <- function(x){
  l <- length(x)
  if(anyNA(x) == 0)
    return(diag(l))
  a <- is.na(x)
  index <- which(a) #index of missing data
  A <- matrix(rep(0, l^2), nrow = l)
  pmt_vec <- c(index, setdiff(1:l, index))
  for (i in 1:l) {
    A[i, which(pmt_vec == i)] <- 1
  }
  return(A)
}

#Input a matrix, output the L1-norm of it.
l1_norm <- function(A){
  return(sum(abs(A)))
}

#Function for calculating A_1, A_2, A_3, A_4
moment_matrix <- function(x, y, mu, Sigma_x, Sigma_y, Beta){
  B11 <- solve(Sigma_x) + Beta %*% solve(Sigma_y) %*% t(Beta)
  B12 <- -Beta %*% solve(Sigma_y)
  B21 <- t(B12)
  B22 <- solve(Sigma_y)
  Sigma <- solve(rbind(cbind(B11, B12), cbind(B21, B22)))
  mu_z <- c(mu, t(Beta) %*% mu)
  l_na_x <- sum(is.na(x))
  l_na_y <- sum(is.na(y))
  z <- c(x, y)
  if(anyNA(z) == 0){
    A_1 <- y %*% t(y)
    A_2 <- y %*% t(x)
    A_3 <- x %*% t(x)
    A_4 <- matrix(x)
    return(list(A_1, A_2, A_3, A_4))
  }

  A <- Pmt(z)
  A_x <- Pmt(x)
  A_y <- Pmt(y)
  l_na_z <- l_na_x + l_na_y
  mu_z_tilde <- t(A) %*% mu_z
  mu_z_miss <- mu_z_tilde[1:l_na_z]
  mu_z_obs <- mu_z_tilde[-1:-l_na_z]
  z_obs <- na.omit(z)
  y_obs <- na.omit(y)
  x_obs <- na.omit(x)
  Sigma_tilde <- t(A) %*% Sigma %*% A
  Sigma_11 <- Sigma_tilde[1:l_na_z, 1:l_na_z]
  if(l_na_z == 1)
    Sigma_12 <- matrix(Sigma_tilde[1:l_na_z, -1:-l_na_z], nrow = 1)
  else
    Sigma_12 <- Sigma_tilde[1:l_na_z, -1:-l_na_z]
  Sigma_21 <- t(Sigma_12)
  Sigma_22 <- Sigma_tilde[-1:-l_na_z, -1:-l_na_z]
  Sigma_11.2 <- Sigma_11 - Sigma_12 %*% solve(Sigma_22) %*% Sigma_21
  E_z_miss <- mu_z_miss + Sigma_12 %*% solve(Sigma_22) %*% (z_obs - mu_z_obs)
  if(l_na_x == 0){
    A_3 <- x %*% t(x)
    A_4 <- matrix(x)
    E_y_miss <- E_z_miss
    E_y_tilde <- c(E_y_miss, y_obs)
    E_y <- A_y %*% E_y_tilde
    A_2 <- E_y %*% t(x)
    N11 <- Sigma_11.2 + E_y_miss %*% t(E_y_miss)
    N12 <- E_y_miss %*% t(y_obs)
    N21 <- t(N12)
    N22 <- y_obs %*% t(y_obs)
    A_1 <- A_y %*% rbind(cbind(N11, N12), cbind(N21, N22)) %*% t(A_y)
    return(list(A_1, A_2, A_3, A_4))
  }
  if(l_na_y == 0){
    A_1 <- y %*% t(y)
    E_x_miss <- E_z_miss
    A_4 <- A_x %*% c(E_x_miss, x_obs)
    A_2 <- y %*% t(A_4)
    M11 <- Sigma_11.2 + E_x_miss %*% t(E_x_miss)
    M12 <- E_x_miss %*% t(x_obs)
    M21 <- t(M12)
    M22 <- x_obs %*% t(x_obs)
    M <- rbind(cbind(M11, M12), cbind(M21, M22))
    A_3 <- A_x %*% M %*% t(A_x)
    return(list(A_1, A_2, A_3, A_4))
  }
  E_x_miss <- E_z_miss[1:l_na_x]
  E_y_miss <- E_z_miss[-1:-l_na_x]
  A_4 <- A_x %*% c(E_x_miss, x_obs)
  E_y_tilde <- c(E_y_miss, y_obs)
  Sigma_x_miss <- Sigma_11.2[1:l_na_x, 1:l_na_x]
  M11 <- Sigma_x_miss + E_x_miss %*% t(E_x_miss)
  M12 <- E_x_miss %*% t(x_obs)
  M21 <- t(M12)
  M22 <- x_obs %*% t(x_obs)
  M <- rbind(cbind(M11, M12), cbind(M21, M22))
  A_3 <- A_x %*% M %*% t(A_x)
  Sigma_y_miss <- Sigma_11.2[-1:-l_na_x, -1:-l_na_x]
  N11 <- Sigma_y_miss + E_y_miss %*% t(E_y_miss)
  N12 <- E_y_miss %*% t(y_obs)
  N21 <- t(N12)
  N22 <- y_obs %*% t(y_obs)
  N <- rbind(cbind(N11, N12), cbind(N21, N22))
  A_1 <- A_y %*% N %*% t(A_y)
  Sigma_xy_miss <- Sigma_11.2[-1:-l_na_x, 1:l_na_x]
  O11 <- Sigma_xy_miss + E_y_miss %*% t(E_x_miss)
  O12 <- E_y_miss %*% t(x_obs)
  O21 <- y_obs %*% t(E_x_miss)
  O22 <- y_obs %*% t(x_obs)
  O <- rbind(cbind(O11, O12), cbind(O21, O22))
  A_2 <- A_y %*% O %*% t(A_x)
  return(list(A_1, A_2, A_3, A_4))
}

sum_A1234 <- function(X, Y, mu, Sigma_x, Sigma_y, beta){
  n <- nrow(X)
  A <- 0
  for(i in 1:n){
    A <- mapply("+", A, moment_matrix(X[i, ], Y[i, ], mu, Sigma_x, Sigma_y, beta))
  }
  return(A)
}

gamma_1D <- function(A, u, G_k){
  if(u == ncol(A[[1]])){
    return(diag(ncol(A[[1]])))
  }
  if(u == 1){
    G_k <- matrix(rep(0, nrow(G_k)), ncol = 1)
  }
  q <- nrow(A[[1]])
  G_0k <- qr.Q(qr(G_k),complete=TRUE)[, u:q]
  if(u == ncol(A[[1]])){
    G_0k <- matrix(G_0k, ncol = 1)
  }
  D_k <- function(w){
    M = t(G_0k) %*% (A[[1]] - A[[2]] %*% solve(A[[3]]) %*% t(A[[2]])) %*% G_0k
    M <- (M + t(M))/2
    U = t(G_0k) %*% solve(A[[1]]) %*% G_0k
    U <- (U + t(U))/2
    return(log(t(w) %*% M %*% w) + log(t(w) %*% U %*% w) - 2*log(t(w) %*% w))
  }
  eig_M <- eigen(t(G_0k) %*% (A[[1]]) %*% G_0k)
  opt <- optim(eig_M$vectors[, 1], D_k, method = "BFGS")
  w_k <- opt$par
  g_k <- (G_0k %*% w_k)/sqrt(sum(w_k^2))
  if(u == 1)
    G_k = g_k
  else
    G_k = cbind(G_k, g_k)
  return(G_k)
}


#Update of parameters using EM-algorithm
update_par <- function(X, Y, mu, Sigma_x, Sigma_y, beta, u, G_k){
  n = nrow(X)
  A <- sum_A1234(X, Y, mu, Sigma_x, Sigma_y, beta)
  A[[1]] <- (A[[1]] + t(A[[1]]))/2 #+ 0.05 * diag(nrow(A[[1]]))
  A[[3]] <- (A[[3]] + t(A[[3]]))/2 #+ 0.05 * diag(nrow(A[[3]]))
  mu_update <- A[[4]]/n
  Sigma_x_update <- (A[[3]] - 2*A[[4]] %*% t(mu_update))/n + mu_update %*% t(mu_update)
  Sigma_x_update <- (Sigma_x_update + t(Sigma_x_update))/2
  gamma_env <- gamma_1D(A, u, G_k)
  #gamma_env <- GAMMA
  Sigma1 <- P(gamma_env) %*% (A[[1]] - A[[2]] %*% solve(A[[3]]) %*% t(A[[2]])) %*% P(gamma_env)/n
  Sigma2 <- Q(gamma_env) %*% A[[1]] %*% Q(gamma_env)/n
  Sigma_y_update <- Sigma1 + Sigma2
  Sigma_y_update <- (Sigma_y_update + t(Sigma_y_update))/2
  beta_update <- solve(A[[3]]) %*% t(A[[2]]) %*% P(Sigma1)
  bic = dim(X)[1] * log(det(P(gamma_env) %*% (A[[1]] - A[[2]] %*% solve(A[[3]]) %*% t(A[[2]])) %*% P(gamma_env) + Q(gamma_env) %*% (A[[1]]) %*% Q(gamma_env))) + dim(X)[2]*u * log(dim(X)[1])
  return(list(mu_update, Sigma_x_update, Sigma_y_update, beta_update, gamma_env, bic))
}






