#' Simulated predictors for demo purpose.
#'
#' @format A matrix of 100 by 5
#' \describe{
#' \item{predictor}{Predictors with ignorable missing data.}
#' }
#'
"predictor"

#' Simulated responses for demo purpose.
#'
#' @format A matrix of 100 by 10
#' \describe{
#' \item{response}{Responses with ignorable missing data.}
#' }
#'
#'
"response"
